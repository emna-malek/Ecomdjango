from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib.auth.decorators import login_required


# Create your views here.


def register_view(request):
    if request.method == 'Post':  # S'il s'agit d'une requête POST
        username = request.Post['username']
        email = request.Post['email']
        password1 = request.Post['password1']
        password2 = request.Post['password2']  # Nous reprenons les données

        user = User.objects.create_user(username=username, email=email, password=password1, )
        user.save()
        print('user created')
        return redirect('login_url')
    else:  # Si ce n'est pas du POST, c'est probablement une requête GET
        return render(request, 'registration/register.html')


@login_required()
def dashbord_view(request):
    return render(request, 'dashbord.html')
